//#include "TestCase.h"
#include "Scanner.h"
#include "Token.h"
#include <iostream>

int main(int argc, char* argv[]) {

	string filename = argv[1];
	Scanner f = Scanner(filename);
	f.Scan(filename);


	return 0;
}
